function zgsm = gsmz(z)
Lz=40;
zgsm= z/Lz*12-10;
return
