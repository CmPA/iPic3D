function ygsm = gsmy(y)
%Ly=30; % For 2D runs
Ly=40; % For 3D runs
ygsm= y/Ly*12-9;
return
