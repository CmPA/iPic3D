
addpath(genpath('/home/gianni/matlab4iPic3D/ipic3d_toolbox'));

clear all
close all

directory='/shared/gianni/tred67/'
cycle=25000
ncycle=num2str(cycle)

yesn=1
yesB=1
yesE=1
yesJ=1

if(yesn)
file=[directory 'rho_xyz_cycle' ncycle '.vtk']

[ne,ni]=read_vtk_multiscalar_3d_bin(file,2);

[Nx,Ny,Nz]=size(ne);

ne=circshift(ne,Nx/2);
ni=circshift(ni,Nx/2);

dx= 0.078125;
dy= 0.078125;
dz=0.078125;

savevtk_bin(ni, 'Ni_shift.vtk','ni',dx,dy,dz,0,0,0)
savevtk_bin(ne, 'Ne_shift.vtk','ne',dx,dy,dz,0,0,0)
end

return

if(yesB)
    file=[directory 'B_xyz_cycle' ncycle '.vtk']

[V,Bx,By,Bz]=read_vtk_3d_bin(file,0);

[Nx,Ny,Nz]=size(Bx);

Vx=circshift(Bx,Nx/2);
Vy=circshift(By,Nx/2);
Vz=circshift(Bz,Nx/2);

dx= 0.078125;
dy= 0.078125;
dz=0.078125;

savevtkvector_bin(Vx, Vy, Vz, 'Bshift.vtk','B',dx,dy,dz,0,0,0)

end



if(yesE) 
    file=[directory 'E_xyz_cycle' ncycle '.vtk']

[V,Ex,Ey,Ez]=read_vtk_3d_bin(file,1);

[Nx,Ny,Nz]=size(Ex);

Vx=circshift(Ex,Nx/2,1);
Vy=circshift(Ey,Nx/2,1);
Vz=circshift(Ez,Nx/2,1);

dx= 0.078125;
dy= 0.078125;
dz=0.078125;

savevtkvector_bin(Vx, Vy, Vz, 'Eshift.vtk','E',dx,dy,dz,0,0,0)

end



if(yesJ)
    file=[directory 'Je_xyz_cycle' ncycle '.vtk']

[V,Jx,Jy,Jz]=read_vtk_3d_bin(file,0);

[Nx,Ny,Nz]=size(Jx);

Vx=circshift(Jx,Nx/2,1);
Vy=circshift(Jy,Nx/2,1);
Vz=circshift(Jz,Nx/2,1);

dx= 0.078125;
dy= 0.078125;
dz=0.078125;

savevtkvector_bin(Vx, Vy, Vz, 'Jeshift.vtk','Je',dx,dy,dz,0,0,0)


    file=[directory 'Ji_xyz_cycle' ncycle '.vtk']
[V,Jx,Jy,Jz]=read_vtk_3d_bin(file,0);

Vx=circshift(Jx,Nx/2,1);
Vy=circshift(Jy,Nx/2,1);
Vz=circshift(Jz,Nx/2,1);

savevtkvector_bin(Vx, Vy, Vz, 'Jishift.vtk','Ji',dx,dy,dz,0,0,0)

end