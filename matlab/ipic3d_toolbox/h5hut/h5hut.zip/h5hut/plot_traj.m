

xgsm=y(:,1);
zgsm=y(:,2);
%plot(y(:,1),y(:,2),y(1,1),y(1,2),'ro',y(end,1),y(end,2),'kx')
plot(xgsm,zgsm,xgsm(1),zgsm(1),'go',xgsm(end),zgsm(end),'kx')
%set(gca,'xdir','reverse')
%axis tight
%xlabel('x/RE')
%ylabel('z/RE')
