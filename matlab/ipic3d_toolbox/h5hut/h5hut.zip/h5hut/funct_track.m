function [t, y] = funct_track(xp,vp)

  global ex ey ez bx by bz xg yg  Lx Ly qom

%options=odeset('AbsTol',10e-1,'RelTol',10e-1,'Stats','off'); 



end
