function dx = newton(t, x)
  global ex ey ez bx by bz xg yg  Lx Ly qom Rout
xp=x(1:3);
vp=x(4:6);
dx = zeros(6,1);

if(xp(1)<0 | xp(1)>Lx) 
    %disp('out in x')
return
end
if(xp(2)<0 | xp(2)>Ly)
    %disp('out in y')
return
end
if (sqrt(xp(1)^2+(xp(2)-Ly/2)^2)>Rout)
     %disp('out in R')
return
end

forward=1;
if(forward)
tdir=1;
else 
tdir=-1;
end

dx(1) = tdir*vp(1);
dx(2) = tdir*vp(2);
dx(3) = tdir*vp(3);


Bp(1) = interp2(xg,yg,bx,xp(1),xp(2));
Bp(2) = interp2(xg,yg,by,xp(1),xp(2));
Bp(3) = interp2(xg,yg,bz,xp(1),xp(2));
Ep(1) = interp2(xg,yg,bx,xp(1),xp(2));
Ep(2) = interp2(xg,yg,by,xp(1),xp(2));
Ep(3) = interp2(xg,yg,bz,xp(1),xp(2));
Fp=cross(vp,Bp);

dx(4) = tdir*qom*(Ep(1) + Fp(1));
dx(5) = tdir*qom*(Ep(2) + Fp(2));
dx(6) = tdir*qom*(Ep(3) + Fp(3));
